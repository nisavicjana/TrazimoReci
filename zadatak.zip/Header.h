#ifndef MyFile
#define MyFile

#include <string>
#include <vector>


class Node {
public:
	Node();
	Node(char c);
	int childExists(char c);
	char getChar();
	std::vector<Node*> getChildren();
	bool isLeaf();
	~Node();

	friend class Root;
	friend class Tree;

	bool endOfWord;

protected:
	char ch;
	std::vector<Node*> children;
	

};

static class Root : public Node{
public:

	void addWord(std::string word);
	
private:

};


class Tree {

public:
	
	Tree();

	void addWord(std::string word);
	Root* getRoot();
	bool checkWordValidation(std::string myWord);
	void printAllWords(std::ostream& out);



private:
	Root root;
};

#endif 

